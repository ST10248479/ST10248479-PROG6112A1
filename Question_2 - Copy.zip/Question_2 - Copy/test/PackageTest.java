/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 *
 * @author lab_services_student
 */
public class PackageTest
{
    private Package pkg;
    
    //Package package = new Package();
   
     @Before
    public void setUp() {
        // Create a new Package object before each test
        pkg = new Package("123456", "Books");
    }
  
    public PackageTest() {
    }

    @Test
    public void testStatusUpdate()
    {
        pkg.statusUpdate("Delivered");
        assertEquals("Delivered", pkg.getStatus());
    }

    @Test
    public void testGetTrackingId()
    {
         assertEquals("123456", pkg.getTrackingId());
    }

    @Test
    public void testGetDescription() 
    {
         assertEquals("Books", pkg.getDescription());
    }

   
    
}
