//ST10248479
public class Package
{
    
   private String trackingId;
   private String description;
   private String status;

   //constructor for package class
    public Package(String trackingId, String description)
    {
        this.trackingId = trackingId;
        this.description = description;
        this.status = "Transit";
    }
   
    //method for updating status
   public void statusUpdate(String updateStatus)
   {
       this.status = updateStatus;
   }

    public String getTrackingId() {
        return trackingId;
    }

    public String getDescription() {
        return description;
    }

    public String getStatus() {
        return status;
    }
    
    
    
}
