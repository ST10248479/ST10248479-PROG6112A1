//ST10248479
import java.util.Scanner;


public class SpeedyDelivery {

    public static void main(String[] args) 
    {
       Scanner kb = new Scanner (System.in);
       System.out.print("Enter the number of packages: ");
       int numPackages = kb.nextInt();
       
       
       //array for package
       Package[] packages = new Package[numPackages];
       kb.nextLine();
        for (int i = 0; i < numPackages; i++) 
        {
            System.out.println("Enter the tracking ID for package "+(i+1)+":");
            String trackingId = kb.nextLine();
            
            System.out.println("Enter description for package " + (i + 1) + ": ");
            String description = kb.nextLine();
            
            //checking if package is local or overseas
            System.out.println("Is the package from overseas - (y) for yest, (n) for no");
            String isOverseas = kb.nextLine();
            
            if (isOverseas.equalsIgnoreCase("y")) 
            {
                System.out.println("Enter destination country: ");
                String destinationCountry = kb.nextLine();
                packages[i] = new OverseasPackage(trackingId, description, destinationCountry);
          
            }
            else
            {
                packages[i] = new Package(trackingId, description);
            }
            System.out.println("\n");
        }//end for
        
        //display the package details
        System.out.println("\nSpeedyDelivery Package Data:\n");
        for (Package p : packages) //loop through the array
        {
            System.out.println("Tracking Number: " + p.getTrackingId());
            System.out.println("Description: " + p.getDescription());
            System.out.println("Status: " + p.getStatus());
            
            //check if package is overseas
            if (p instanceof OverseasPackage) 
            {
                OverseasPackage overseasPackage = (OverseasPackage) p;
                System.out.println("Destination: "+overseasPackage.getCountryDestination());
            }
            
        }
        //ask user if status is to be updated
        System.out.println("Would you like to update a delivery status: (y/n)");
        String choiceUpdate = kb.nextLine();
        if (choiceUpdate.equalsIgnoreCase("y")) 
        {
            System.out.print("Enter a tracking number to update status: ");
            String trackingNumberToUpdate = kb.nextLine();
            
            for (Package p : packages) //for loop that runs through package 
            {
            if (p.getTrackingId().equals(trackingNumberToUpdate)) 
            {
                System.out.print("Enter new status: ");
                String newStatus = kb.nextLine();
                p.statusUpdate(newStatus);
                break;
            }
            }
         
          System.out.println("\nUPDATED: SpeedyDelivery Package Data:\n");
          for (Package u : packages) //loop through the array
        {
            System.out.println("Tracking Number: " + u.getTrackingId());
            System.out.println("Description: " + u.getDescription());
            System.out.println("Status: " + u.getStatus());
            
            //check if package is overseas
            if (u instanceof OverseasPackage) 
            {
                OverseasPackage overseasPackage = (OverseasPackage) u;
                System.out.println("Destination: "+overseasPackage.getCountryDestination());
            }
            
        }
        }//end if 
        
        else
        {
            System.out.println("Exiting");
            System.exit(0);
        }
        
        
    }//end main
    
}
