//ST10248479
//class for packages with overseas delivery 
public class OverseasPackage extends Package
{

    private String countryDestination;
    //constructor
    public OverseasPackage(String trackingId, String description, String countryDestination) {
        super(trackingId, description);
        this.countryDestination = countryDestination;
    }
    //getter and setter
    public String getCountryDestination() {
        return countryDestination;
    }
    
    
    
    
}
