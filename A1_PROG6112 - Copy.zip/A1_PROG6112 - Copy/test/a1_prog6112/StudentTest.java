//ST10248479
package a1_prog6112;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;



public class StudentTest 
{
    private Student student;
    
    @Before
    public void setUp() 
    {
        // student object
        student = new Student();
    }
    public StudentTest() {
    }

    @Test
    public void testSaveStudent()
    {
        
        // student information
        int studentID = 10112;
        String name = "A.Smith";
        int age = 20;
        String email = "asmith1@jmail.com";
        String course = "disd";

        

        //  populate student fields based on user input
        student.studentID.add(studentID);
        student.studentName.add(name);
        student.studentAge.add(age);
        student.studentEmail.add(email);
        student.studentCourse.add(course);
        
        student.SaveStudent();
       
        int savedStudentID = student.studentID.get(0);
        String savedStudentName = student.studentName.get(0);
        int savedStudentAge = student.studentAge.get(0);
        String savedStudentEmail = student.studentEmail.get(0);
        String savedStudentCourse = student.studentCourse.get(0);


        assertEquals(studentID, savedStudentID);
        assertEquals(name, savedStudentName);
        assertEquals(age, savedStudentAge);
        assertEquals(email, savedStudentEmail);
        assertEquals(course, savedStudentCourse);
        
      
    }
    
  

    @Test
    public void testSearchStudent()
    {
        int searchID = 10112;
        student.SearchStudent(searchID);
    }
     
    
    @Test
    public void TestSearchStudent_StudentNotFound() 
    {
        // incorrect student ID to search for
        int searchID = 8094;

        //  search
        student.SearchStudent(searchID);

        
    }

   
    @Test
    public void testDeleteStudent() 
    {
        
        int deleteStudentId = 10112;
        
        student.SaveStudent();
        student.DeleteStudent(deleteStudentId);
        assertEquals(0, student.studentID.size());
       
    
    }

     @Test
    public void TestDeleteStudent_StudentNotFound() 
    {
        //  incorrect student ID to delete
        int deletStudenteId = 10112;

        //  delete the student
        student.DeleteStudent(deletStudenteId);

       
        assertEquals(0, student.studentID.size());
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Supply a valid student age
        int validAge = 20;

        // Check if the age is valid
        assertTrue(student.ageCheck(validAge));
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        // Supply an invalid student age (less than 16)
        int invalidAge = 15;

        // Check if the age is invalid
        assertFalse(student.ageCheck(invalidAge));
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Supply an invalid character as student age
        int invalidCharacterAge = -1; 

        // Check if the age is invalid
        assertFalse(student.ageCheck(invalidCharacterAge));
    }
}
