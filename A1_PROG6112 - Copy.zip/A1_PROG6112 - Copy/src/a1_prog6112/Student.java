
package a1_prog6112;
//ST10248479
//Student Program to manage methods
import java.util.ArrayList;
import java.util.Scanner;

public class Student 
{
    Scanner kb = new Scanner (System.in);
  
    //create arrayList of each variable
     ArrayList<String> studentName = new ArrayList<>();
     ArrayList<Integer> studentID = new ArrayList<>();
     ArrayList<Integer> studentAge = new ArrayList<>();
     ArrayList<String> studentEmail = new ArrayList<>();
     ArrayList<String> studentCourse = new ArrayList<>();
   
     
     
     //case 1: 
    public void SaveStudent()
    {
        
         
                    System.out.println("CREATE A NEW STUDENT");
                    System.out.println("*************************");
                    
                    //enter studentID
                    System.out.print("Enter the student id: ");
                    int stuID = kb.nextInt();
                    this.studentID.add(stuID);
            
                    //enter studentName
                    System.out.print("Enter the student name: ");
                    String stuName = kb.next();
                    this.studentName.add(stuName);

                    //enter studentName
                    System.out.print("Enter the student age: ");
                    String ageStudent = kb.next();
                   
                    while (true) 
                    {
                        try //try and catch is to handle the exceptions such as a string input
                        {
                            //convert string to integer as integer is saved in stuAge value
                           int stuAge = Integer.parseInt(ageStudent);

                           //validation with ageCheck method to confirm if age is >=16 and not a string
                           if (ageCheck(stuAge)) 
                           {
                              System.out.println("Age is valid.");
                              this.studentAge.add(stuAge);
                              break;
                           } 
                           else 
                          {
                            System.out.print("You have entered an incorrect student age!!!\nPlease re-enter the student age: ");
                            ageStudent = kb.next();
               }
                        }//end try
                        catch (NumberFormatException e)
                       {
                            System.out.print("You have entered an invalid input!!!\nPlease re-enter the student age: ");
                             ageStudent = kb.next();
                        }//end catch
                 }//end while
                    
                   
                    //eneter studentEmail
                    System.out.print("Enter the student email: ");
                    String stuEmail = kb.next();
                    this.studentEmail.add(stuEmail);
                    
                    //eneter studentCourse
                    System.out.print("Enter the student course: ");
                    String stuCourse = kb.next();
                    this.studentCourse.add(stuCourse);
                    
                  
        System.out.println("STUDENT SUCCESSFULLY ADDED");
        
      
    }
   
    //case 2:
    public void SearchStudent(int searchID)
    {
  
        //boolean variable to determine if the studentID is found
        boolean foundStu = false;
       
        
        //loop through studentID list to search for the matching input of studentID
        for (int i = 0; i < studentID.size(); i++)
        {
            if (searchID == studentID.get(i)) 
            {
            foundStu = true;
            
            System.out.println("----------------------------------");
            System.out.println("STUDENT ID: "+studentID.get(i));
            System.out.println("STUDENT NAME: "+studentName.get(i));
            System.out.println("STUDENT AGE: "+studentAge.get(i));
            System.out.println("STUDENT EMAIL: "+studentEmail.get(i));
            System.out.println("STUDENT COURSE: "+studentCourse.get(i));
            System.out.println("----------------------------------");
            
            }//end if 
           
        }//end for 
         if (foundStu == false)
            {
                 System.out.println("----------------------------------");
                 System.out.println("Student with Student ID: "+searchID+" was not found!");
                 System.out.println("----------------------------------");
            }//end else if 
     


    }
    
    //case 3:
    public void DeleteStudent(int deleteID) //user input of studentID to delete
    {
        boolean found = false;
        String confirmDelete = "";
        
        for (int i = 0; i < studentID.size(); i++)
        {
            if (deleteID == studentID.get(i)) 
            {
                found = true;
                //ask user to double confirm the act of deleting the student - user friendly
                System.out.println("Are you sure you want to delete student "+deleteID+" from the system? Yes (y) to delete or (n) to cancel. ");
                confirmDelete = kb.next();
                
                if (confirmDelete.equalsIgnoreCase("y")) 
                {
                    studentID.remove(i);
                    studentName.remove(i);
                    studentAge.remove(i);
                    studentEmail.remove(i);
                    studentCourse.remove(i);
                    
                    System.out.println("-----------------------------------------------");
                    System.out.println("Student with Student Id: "+deleteID+ " WAS deleted!");
                    System.out.println("-----------------------------------------------");
                }//end if 
                else
                {
                    System.out.println("Student ID with id "+deleteID + " was not deleted");  
                }//end else
                
                
            }//end if (deleteID...)
            
        }//end for
         if (found == false)
            {
                 System.out.println("----------------------------------");
                 System.out.println("Student with Student ID: "+deleteID+" was not found!");
                 System.out.println("----------------------------------");
            }//end else if 
        
        
    }
   
    //case 4: prints all the students information
    public void StudentReport()
    {
        for (int i = 0; i < studentID.size(); i++) 
        {
            
            System.out.println("STUDENT "+ (i+1));
            System.out.println("----------------------------------");
            System.out.println("STUDENT ID: "+studentID.get(i));
            System.out.println("STUDENT NAME: "+studentName.get(i));
            System.out.println("STUDENT AGE: "+studentAge.get(i));
            System.out.println("STUDENT EMAIL: "+studentEmail.get(i));
            System.out.println("STUDENT COURSE: "+studentCourse.get(i));
            System.out.println("----------------------------------");
        }
        
    }
    
    //checks age - for validation by asking user to input age, it will "catch" if it does not meet the condition
    public boolean ageCheck(int age)
    {
          return age >= 16;
      
    }
    
    //case 5:
    //exits the application 
    public void ExitStudentApplication()
    {
        System.out.println("Application Closed");
        System.exit(0);
    }
   
   
    
}//end public class Student
