
package a1_prog6112;

//ST10248479
import java.util.ArrayList;
import java.util.Scanner;


public class A1_PROG6112 
{

    public static void main(String[] args)
    {
        
        Scanner kb = new Scanner (System.in);
        Student stu = new Student();
       
        String choice = "";
        int menuItem; //to determine what the user enetered when selecting item
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("**************************************");
        while(true)
      {
        System.out.println("Enter (1) to launch menu or any other key to exit");
        choice = kb.next();
      
        //if to check if user entered "1"
        if (choice.equalsIgnoreCase("1"))
        {
            
            System.out.println("Please select one of the following menu items:\n"
                    + "(1) Capture a new student.\n"
                    + "(2) Search for a student.\n"
                    + "(3) Delete a student.\n"
                    + "(4) Print student report.\n"
                    + "(5) Exit Application ");
            menuItem = kb.nextInt();
            int studentAge;
            
            switch (menuItem)
            {
                case 1:  
                    //call SaveStudent method
                         stu.SaveStudent();
                       
                         break;
                        
                case 2:
                         System.out.print("Enter the student id to search: ");
                         int searchID = kb.nextInt();
                         //call SearchStudent method
                         stu.SearchStudent(searchID);
                    
                         break;
                case 3:
                        System.out.print("Enter the student id to delete: ");
                        int deleteID = kb.nextInt();
                        //call DeleteStudent method
                        stu.DeleteStudent(deleteID);
                        break;
                case 4:
                    //print StudentReport method
                        stu.StudentReport();
                        break;
                case 5:
                        //System.exit(0);
                        stu.ExitStudentApplication();
                        break;
                default:
                    //default entry
                        System.out.println("Invalid Entry");
                        break;
          }//end switch
        }//end if
        else
        {
            System.out.println("Exiting...");
            System.exit(0);
        }//end else
        
        }
    }//end main
    
}
